<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran"><?php echo e(__('لیست کاربران')); ?></div>

                    <div class="card-body iran">

                        <ul class="list-group iran" style="padding: 0; margin: 0 !important;">

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="container-fluid mb-2">
                                    <a class="btn btn-danger iran" style="width: 35%" href="">
                                       <?php echo e($user->name); ?>

                                    </a>
                                    <a class="btn btn-primary collapsed iran" type="button" style="width:60%;">
                                        جزئیات بیشتر
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                    <div style="align-content: center;align-items: center">
                        <?php echo e($users->onEachSide(0)->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/admin/usersList.blade.php ENDPATH**/ ?>