<li class="nav-item">
    <a class="nav-link iran" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('داشبورد')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="<?php echo e(route('usersList')); ?>"><?php echo e(__('کاربران')); ?></a>
</li>
<li class="nav-item">
<a class="nav-link iran" href="<?php echo e(route('templates')); ?>"><?php echo e(__('قالب ها')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="<?php echo e(route('categories')); ?>"><?php echo e(__('دسته بندی')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="<?php echo e(route('fontsList')); ?>"><?php echo e(__('فونت ها')); ?></a>
</li>
<li class="nav-item">
<a class="nav-link iran" href="<?php echo e(route('resultsList')); ?>"><?php echo e(__('نتایج')); ?></a>
</li><li class="nav-item">
<a class="nav-link iran" href="<?php echo e(route('setting')); ?>"><?php echo e(__('تنظیمات')); ?></a>
</li>






<?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/layouts/menu.blade.php ENDPATH**/ ?>