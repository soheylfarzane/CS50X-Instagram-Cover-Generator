<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran"><?php echo e(__('داشبورد')); ?></div>

                    <div class="card-body">

<h2 class="iran">تا الان <?php echo e($countUsers); ?> کاربر عضو شده.</h2>
                        <br>
                        <h2 class="iran">تا الان <?php echo e($countResults); ?> فایل طراحی شده.</h2>
                        <br>
                        <h2 class="iran">تا الان <?php echo e($countTemplates); ?> قالب اضافه شده.</h2>
                        <br>
                        <h2 class="iran">تا الان <?php echo e($countFonts); ?> فونت اضافه شده.</h2>
                        <br>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>