<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran"><?php echo e(__('تولید عکس و استوری')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('fail')): ?>
                            <div class="alert alert-danger iran" role="alert">
                                <?php echo e(session('fail')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="container">
                            <div class="row mb-3">
                                <div class="col-md-4">
                                </div>
                                <div class="col-md-4">
                                    <img src="/<?php echo e($template->thumbnail); ?>" class="img-fluid">
                                </div>
                            </div>
                        </div>


                            <p>

                            </p>
                        <form method="POST" action="<?php echo e(route('generator',$template->slug)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="row mb-3">
                                <label for="email"
                                       class="col-md-4 col-form-label text-md-end float-start iran"><?php echo e(__('فایل پس زمینه را انتخاب کنید')); ?></label>

                                <div class="col-md-6">
                                    <input id="image" type="file"
                                           class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> iran" name="image"
                                           value="<?php echo e(old('image')); ?>">

                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback iran" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                            </div>

                            <div class="row mb-3">
                                <label for="headding1"
                                       class="col-md-4 col-form-label text-md-end iran"><?php echo e(__('عنوان را وارد کنید')); ?></label>

                                <div class="col-md-6">
                                    <input id="headding1" type="text"
                                           class="form-control <?php $__errorArgs = ['headding1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> iran"
                                           name="headding1" value="<?php echo e(old('headding1')); ?>">

                                    <?php $__errorArgs = ['headding1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback iran" role="alert">
                                        <strong class="iran"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="headding1Font"
                                       class="col-md-4 col-form-label text-md-end iran"><?php echo e(__('فونت عنوان را انتخاب کنید')); ?></label>

                                <div class="col-md-6">
                                    <select id="headding1Font"
                                            class="form-control iran <?php $__errorArgs = ['headding1Font'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="headding1Font">
                                        <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($font->id); ?> "><?php echo e($font->name); ?>  <?php echo e($font->weight); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['headding1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="headding2"
                                       class="col-md-4 col-form-label text-md-end iran"><?php echo e(__('زیر عنوان را وارد کنید')); ?></label>

                                <div class="col-md-6">
                                    <input id="headding2" type="text"
                                           class="form-control iran <?php $__errorArgs = ['headding2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="headding2" value="<?php echo e(old('headding2')); ?>">

                                    <?php $__errorArgs = ['headding2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback iran" role="alert">
                                        <strong class="iran"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="headding2Font"
                                       class="col-md-4 col-form-label text-md-end iran"><?php echo e(__('فونت زیر عنوان را انتخاب کنید')); ?></label>

                                <div class="col-md-6">
                                    <select id="headding2Font"
                                            class="form-control iran <?php $__errorArgs = ['headding2Font'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="headding2Font">
                                        <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($font->id); ?>"><?php echo e($font->name); ?>  <?php echo e($font->weight); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['headding2Font'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback iran" role="alert">
                                        <strong class="iran"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="container mt-5">
                                <div class="row justify-content-center">
                                    <div class="col-md-6">
                                        <div class="mt-3 iran" id="countdownTimer" style="display: none;">
                                            <span id="countdown"></span> ثانیه در حال ساخت کاور...

                                            <br>
                                            <br>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="container mb-0">
                                <div class="iran">
                                    <button type="submit" id="startButton" class="btn btn-primary col-12">
                                        <?php echo e(__('بساز')); ?>

                                    </button>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        // Function to start the countdown timer
        function startCountdownTimer() {
            let seconds = 10;

            // Hide the submit button
            $('#submitButton').hide();

            // Show the countdown timer
            $('#countdownTimer').show();

            // Display the initial countdown value
            $('#countdown').text(seconds);

            // Start the countdown
            const countdownInterval = setInterval(() => {
                seconds--;
                $('#countdown').text(seconds);

                // When the countdown reaches 0, stop the interval and show the submit button
                if (seconds === 0) {
                    clearInterval(countdownInterval);
                    $('#countdownTimer').hide();
                    $('#submitButton').show();
                }
            }, 1000);
        }

        // When the "Start Countdown" button is clicked, trigger the countdown timer
        $('#startButton').on('click', startCountdownTimer);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appNoMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/createForm.blade.php ENDPATH**/ ?>