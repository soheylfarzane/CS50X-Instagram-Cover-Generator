<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card iran">
                <div class="card-header iran"><?php echo e(__('دانلود فایل')); ?></div>

                <div class="card-body iran">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <img class="img-fluid" src="/<?php echo e($path); ?>">

                    <a href="<?php echo e($path); ?>" class="btn btn-primary col-6 iran float-start" style="margin-top: 25px">دریافت فایل</a>
                    <a href="/" class="btn btn-outline-primary col-6 iran float-start" style="margin-top: 25px">برگرد صفحه اصلی</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appNoMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/result.blade.php ENDPATH**/ ?>