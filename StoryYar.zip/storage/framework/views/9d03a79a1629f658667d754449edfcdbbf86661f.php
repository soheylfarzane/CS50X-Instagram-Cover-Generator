<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran">
                        <p class="float-end"><?php echo e(__('آخرین طراحی های کاربران')); ?></p>

                    </div>

                    <div class="card-body">

                        <div class="container">

                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($result->path == '#'): ?>
                                    <?php else: ?>
                                        <div class="col">
                                            <div class="card shadow-sm">
                                                <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="<?php echo e($result->path); ?>" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">

                                                <rect width="100%" height="100%" fill="#55595c"></rect>
                                                </img>
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between align-items-center iran">

                                                        <a href="<?php echo e($result->path); ?>" class="btn btn-sm btn-primary  m1 iran">مشاهده تصویر با کیفیت</a>

                                                        <form class="float-start iran m-1" action="<?php echo e(route('resultsDelete',$result->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <button class="btn btn-outline-danger" type="submit">
                                                                حذف
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/admin/resultsList.blade.php ENDPATH**/ ?>