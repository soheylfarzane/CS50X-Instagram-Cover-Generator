<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran">
                        <p class="float-end"><?php echo e(__('قالب ها')); ?></p>
                    </div>

                    <div class="card-body">

                        <div class="container">

                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

                                <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="card shadow-sm">
                                            <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="<?php echo e($template->thumbnail); ?>" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">

                                            <rect width="100%" height="100%" fill="#55595c"></rect>
                                            <text class="iran" style="padding: 10px" x="50%" y="50%" fill="#eceeef" dy=".3em"><?php echo e($template->name); ?></text></img>
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center iran">

                                                    <a href="/generate/<?php echo e($template->slug); ?>" class="btn btn-sm btn-primary iran">ساخت کاور</a>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appNoMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/welcome.blade.php ENDPATH**/ ?>