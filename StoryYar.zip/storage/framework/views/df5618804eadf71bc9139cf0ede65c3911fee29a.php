<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header iran">
                        <p class="float-end"><?php echo e(__('فونت ها')); ?></p>
                        <a class="btn btn-success float-start" type="submit" href="<?php echo e(route('addFont')); ?>">افزودن فونت</a>
                    </div>

                    <div class="card-body">

                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('fail')): ?>
                            <div class="alert alert-danger iran" role="alert">
                                <?php echo e(session('fail')); ?>

                            </div>
                        <?php endif; ?>
                        <ul class="list-group iran" style="padding: 0; margin: 0 !important;">

                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <a class="btn btn-primary col-8 float-start iran m-1" href="">
                                        <?php echo e($font->name); ?>

                                        -
                                        <?php echo e($font->weight); ?>

                                    </a>
                                    <form class="col-2  float-start iran m-1" action="<?php echo e(route('deleteFont',$font->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger" type="submit">
                                            حذف
                                        </button>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\To Do\Develop\Web develop\Back end\php\Laravel\StoryYar\resources\views/admin/fontsList.blade.php ENDPATH**/ ?>