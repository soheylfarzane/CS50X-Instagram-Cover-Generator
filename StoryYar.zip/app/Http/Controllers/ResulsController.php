<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ResulsController extends Controller
{
    //
}
