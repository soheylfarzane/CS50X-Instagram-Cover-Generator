<li class="nav-item">
    <a class="nav-link iran" href="{{ route('dashboard') }}">{{ __('داشبورد') }}</a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="{{ route('usersList') }}">{{ __('کاربران') }}</a>
</li>
<li class="nav-item">
<a class="nav-link iran" href="{{ route('templates') }}">{{ __('قالب ها') }}</a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="{{ route('categories') }}">{{ __('دسته بندی') }}</a>
</li>
<li class="nav-item">
    <a class="nav-link iran" href="{{ route('fontsList') }}">{{ __('فونت ها') }}</a>
</li>
<li class="nav-item">
<a class="nav-link iran" href="{{ route('resultsList') }}">{{ __('نتایج') }}</a>
</li><li class="nav-item">
<a class="nav-link iran" href="{{ route('setting') }}">{{ __('تنظیمات') }}</a>
</li>
{{--<li class="nav-item">--}}
{{--    <a class="nav-link iran" href="{{ route('addCategory') }}">{{ __('کد های تخفیف') }}</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--    <a class="nav-link iran" href="{{ route('addCategory') }}">{{ __('پلن ها') }}</a>--}}
{{--</li>--}}
